from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.contrib import messages

def admin_login(request):
    if request.method == "POST":
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']
        
        # Authenticate Admin (checks username & password)
        user = authenticate(request, username=username, password=password)
        
        if user is not None and user.is_staff:  # Only allow admin users
            login(request, user)
            return redirect("dashboard")  # Redirect to admin dashboard
        else:
            messages.error(request, "Invalid Credentials or Not an Admin")
    
    return render(request, 'admins/admin_login.html')

def dashboard(request):
    return render(request, 'admins/dashboard.html')
