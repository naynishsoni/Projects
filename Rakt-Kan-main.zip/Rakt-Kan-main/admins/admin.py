from django.contrib import admin
from .models import AdminProfile

admin.site.register(AdminProfile)
