# admins/urls.py
from django.urls import path
from admins.views import dashboard
from .views import admin_login


urlpatterns = [
    path('admin_login/', admin_login, name='admin_login'),
    path('dashboard/', dashboard, name='dashboard'),
]
