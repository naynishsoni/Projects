# bloodbank/models.py
from django.db import models

class BloodBank(models.Model):
    name = models.CharField(max_length=100)
    city = models.CharField(max_length=100)
    address = models.TextField()

    def __str__(self):
        return self.name
