from django.apps import AppConfig


class BloodbanksConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'bloodbanks'
