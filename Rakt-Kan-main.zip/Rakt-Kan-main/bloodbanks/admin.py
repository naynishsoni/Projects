from django.contrib import admin
from .models import BloodBank

admin.site.register(BloodBank)