# bloodbank/views.py
from django.shortcuts import render
from .models import BloodBank

def find_blood_bank(request):
    bloodbanks = None
    if request.method == "GET":
        city = request.GET.get('location')
        if city:
            bloodbanks = BloodBank.objects.filter(city__icontains=city)
    return render(request, 'bloodbanks/find_blood_bank.html', {'bloodbanks': bloodbanks})
