# donor/forms.py
from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import Donor

class DonorRegistrationForm(UserCreationForm):
    confirm_password = forms.CharField(widget=forms.PasswordInput())

    class Meta:
        model = Donor
        fields = [
            'full_name', 'username', 'email', 'dob', 'gender', 'profile_picture',
            'password1', 'password2', 'mobile_number', 'alternate_contact', 'share_contact',
            'blood_group', 'last_donation_date', 'thalassemia_status',
            'house_number', 'street', 'zip_code', 'country', 'state', 'city', 'latitude', 'longitude'
        ]

    def clean(self):
        cleaned_data = super().clean()
        pw1 = cleaned_data.get("password1")
        pw2 = cleaned_data.get("password2")
        if pw1 and pw2 and pw1 != pw2:
            raise forms.ValidationError("Passwords do not match.")
