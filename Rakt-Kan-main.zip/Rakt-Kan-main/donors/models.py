from django.db import models
from django.contrib.auth.models import AbstractUser, Group, Permission

class Donor(AbstractUser):
    full_name = models.CharField(max_length=100)
    dob = models.DateField()
    gender = models.CharField(max_length=10, choices=[('Male', 'Male'), ('Female', 'Female'), ('Other', 'Other')], default='Other')

    profile_picture = models.ImageField(upload_to='profile_pics/', null=True, blank=True)

    mobile_number = models.CharField(max_length=15)
    alternate_contact = models.CharField(max_length=15, null=True, blank=True)
    share_contact = models.BooleanField(default=False)

    blood_group = models.CharField(max_length=5, choices=[ 
        ('A+', 'A+'), ('A-', 'A-'), ('B+', 'B+'), ('B-', 'B-'),
        ('AB+', 'AB+'), ('AB-', 'AB-'), ('O+', 'O+'), ('O-', 'O-')
    ])
    last_donation_date = models.DateField(null=True, blank=True)
    thalassemia_status = models.BooleanField(default=False)

    house_number = models.CharField(max_length=100)
    street = models.CharField(max_length=100)
    zip_code = models.CharField(max_length=10)
    country = models.CharField(max_length=50)
    state = models.CharField(max_length=50)
    city = models.CharField(max_length=50)
    latitude = models.FloatField(null=True, blank=True)
    longitude = models.FloatField(null=True, blank=True)

    date_joined = models.DateTimeField(auto_now_add=True)

    # Custom related_name to avoid conflicts
    groups = models.ManyToManyField(Group, related_name='donor_groups', blank=True)
    user_permissions = models.ManyToManyField(Permission, related_name='donor_permissions', blank=True)

    def __str__(self):
        return self.username
