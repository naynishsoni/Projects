# donor/urls.py
from django.urls import path
from donors import views
from .views import donor_dashboard, leaderboard,donor_login

urlpatterns = [
     path('register/', views.register_donor, name='donor_register'),
    path('dashboard/', donor_dashboard, name='donor_dashboard'),
    path('leaderboard/', leaderboard, name='leaderboard'),
    path("login/", donor_login, name="donor_login"),
    path('profile/', views.donor_profile, name='donor_profile'),
    path('schedule/', views.schedule_donation, name='schedule_donation'),
    path('impact/', views.my_impact, name='my_impact'),
    path('resources/', views.resources, name='resources'),
    path('community/', views.community, name='community'),
    path('faq/', views.faq, name='faq'),
    path('logout/', views.logout_view, name='logout'),
]
