# donor/views.py
from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from .forms import DonorRegistrationForm
from .models import Donor
from django.utils.timezone import now
import logging

# Set up logging for debugging
logger = logging.getLogger(__name__)

def register_donor(request):
    if request.method == 'POST':
        form = DonorRegistrationForm(request.POST, request.FILES)
        if form.is_valid():
            donor = form.save()
            messages.success(request, "Registration successful! Welcome, donor!")
            login(request, donor)
            return redirect('donor_dashboard')
        else:
            messages.error(request, "Please correct the errors below.")
    else:
        form = DonorRegistrationForm()

    return render(request, 'donors/donor_register.html', {'form': form})

def donor_login(request):
    if request.method == "POST":
        username = request.POST.get("username")  # Use "username" instead of "email"
        password = request.POST.get("password")

        donor = authenticate(request, username=username, password=password)

        if donor is not None:
            login(request, donor)
            return redirect("donor_dashboard")  # Redirect to donor dashboard after login
        else:
            messages.error(request, "Invalid username or password.")

    return render(request, "donors/donor_login.html")

@login_required(login_url='donor_login')
def donor_dashboard(request):
    try:
        donor_profile = Donor.objects.get(username=request.user.username)  # Fetch donor object
    except Donor.DoesNotExist:
        return render(request, "error.html", {"message": "User profile not found"})

    return render(request, "donors/donor_dashboard.html", {"donor_profile": donor_profile})

def leaderboard(request):
    top_donors = Donor.objects.order_by('-donation_count')[:10]  # Ensure donation_count field exists
    return render(request, "donors/leaderboard.html", {'top_donors': top_donors})

@login_required(login_url='donor_login')
def donor_profile(request):
    donor = Donor.objects.get(username=request.user.username)  # Fetch donor instance
    profile_picture_url = donor.profile_picture.url if donor.profile_picture else None  # Handle missing picture

    return render(request, "donors/profile.html", {"donor": donor, "profile_picture_url": profile_picture_url})

@login_required(login_url='donor_login')
def schedule_donation(request):
    return render(request, "donors/schedule.html")

@login_required(login_url='donor_login')
def my_impact(request):
    donor, created = Donor.objects.get_or_create(
        username=request.user.username,
        defaults={
            "email": request.user.email,
            "full_name": request.user.get_full_name() or request.user.username,
            "mobile_number": "1234567890",  # Placeholder (update accordingly)
            "dob": "2000-01-01",  # Default dob to prevent IntegrityError
        },
    )

    return render(request, "donors/impact.html", {"donor": donor})

@login_required(login_url='donor_login')
def resources(request):
    return render(request, "donors/resources.html")

@login_required(login_url='donor_login')
def community(request):
    return render(request, "donors/community.html")

@login_required(login_url='donor_login')
def faq(request):
    return render(request, "donors/faq.html")

def logout_view(request):
    messages.success(request, "You have been logged out successfully.")
    logout(request)
    return redirect('donor_login')
