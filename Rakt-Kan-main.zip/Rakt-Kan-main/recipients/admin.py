from django.contrib import admin
from .models import RecipientProfile

admin.site.register(RecipientProfile)