# recipient/urls.py
from django.urls import path
from .views import recipient_register, recipient_dashboard
from .views import recipient_login


urlpatterns = [
    path('register/', recipient_register, name='recipient_register'),
    path('dashboard/', recipient_dashboard, name='recipient_dashboard'),
    path("login/", recipient_login, name="recipient_login"),
]
