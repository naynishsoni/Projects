# recipient/views.py
from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib import messages
from .models import RecipientProfile
from django.contrib.auth import authenticate, login
from django.contrib.auth.decorators import login_required


def recipient_register(request):
    if request.method == "POST":
        username = request.POST["username"]
        password = request.POST["password"]
        blood_needed = request.POST["blood_needed"]
        city = request.POST["city"]
        urgency = request.POST.get("urgency", "")
        
        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already exists!")
        else:
            user = User.objects.create_user(username=username, password=password)
            RecipientProfile.objects.create(user=user, blood_needed=blood_needed, city=city, urgency=urgency)
            messages.success(request, "Registration successful!")
            return redirect("recipients/recipient_login")
    return render(request, "recipients/recipient_register.html")

def recipient_login(request):
    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")
        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect("recipient_dashboard")  # Redirect to recipient dashboard
        else:
            messages.error(request, "Invalid username or password.")

    return render(request, "recipients/recipient_login.html")

@login_required(login_url='recipient_login')
def recipient_dashboard(request):
    return render(request, "recipients/recipient_dashboard.html")
