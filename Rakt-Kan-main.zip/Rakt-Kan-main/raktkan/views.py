# raktkan/views.py
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages

def register_choice(request):
    # A simple page that gives a choice to register as a donor or recipient
    return render(request, "register.html")

def home(request):
    return render(request, 'home.html')

def register(request):
    # Render a registration choice page (Donor or Recipient)
    return render(request, 'register.html')
