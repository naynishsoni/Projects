from django.contrib import admin
from django.urls import path, include
from django.shortcuts import render  # Import render for lambda functions
from raktkan.views import home, register  # Import your views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', home, name='home'),  # Home page URL pattern
    path('login/', include('django.contrib.auth.urls')),  # Built-in auth URLs
    path('register/', register, name='register'),  # Direct registration view
    path('dashboard/', include('admins.urls')),
    path('find_blood_bank/', include('bloodbanks.urls')),
    path('donor/', include('donors.urls')),
    path('recipient/', include('recipients.urls')),
    path('blogs/', lambda request: render(request, 'blogs.html'), name='blogs'),
    path('donation_drive/', lambda request: render(request, 'donation_drive.html'), name='donation_drive'),
    path('feedback/', lambda request: render(request, 'feedback.html'), name='feedback'),
]
