
Frontend
--------
This is a static frontend that expects the backend Flask app to be running on the same host (http://localhost:5000).
Serve it with any static server, or open frontend/index.html in a browser (if you run Flask on the same machine, the relative fetch to /api/query will work when both are served from the same origin).
