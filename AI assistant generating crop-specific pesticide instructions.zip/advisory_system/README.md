
Crop Protection Advisory — Fullstack Demo
=======================================

Contents:
- backend/  : Flask API (app.py, requirements.txt)
- frontend/ : Static single-page app (index.html)

Quick start (local):
1. Start the backend (see backend/README.md)
2. Open frontend/index.html in a browser OR serve the frontend from the same origin as the backend.
3. Check the disclaimer checkbox, type a query like 'Aphids on tomato', and click 'Get Recommendations'.

Notes:
- This demo uses a small in-memory vetted knowledge base. It intentionally avoids automatic pesticide rate suggestions — the response always tells users to follow product labels.
- For production, add authentication, rate limiting, and stronger intent classification (e.g., transformers).

