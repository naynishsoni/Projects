
from flask import Flask, request, jsonify
from typing import Optional

app = Flask(__name__)

# Minimal vetted knowledge base (a small subset from user's KB)
PESTICIDE_KNOWLEDGE_BASE = {
    "tomato_aphids": {
        "crop": "Tomato",
        "target_pest": "Aphids (General)",
        "pest_description": "Small, soft-bodied insects (green, black, red) on undersides of leaves, causing curling and honeydew.",
        "ipm_recommendations": [
            "Introduce/cons beneficial insects: ladybugs, lacewings, parasitic wasps.",
            "Use insecticidal soaps or horticultural oils for light infestations.",
            "Apply strong water spray to dislodge nymphs.",
            "Remove heavily infested plant parts."
        ],
        "chemical_options": [
            {
                "common_name": "Insecticidal Soap",
                "example_product": "Safer's End All",
                "moa_group": "N/A",
                "considerations": "Contact killer. Requires thorough spray coverage on leaf undersides. Low impact on beneficials. PHI: 0 days. REI: 4 hours.",
                "rate_reference": "APPLY AT RATE SPECIFIED ON THE PRODUCT LABEL.",
                "safety_warnings": ["Do not apply in full sun or high temperatures to avoid leaf burn."]
            },
            {
                "common_name": "Azadirachtin",
                "example_product": "Neem Oil, AzaSol",
                "moa_group": "UN",
                "considerations": "Antifeedant & growth regulator. Best used as a preventative or for young pests. PHI: 0 days. REI: 4 hours.",
                "rate_reference": "APPLY AT RATE SPECIFIED ON THE PRODUCT LABEL.",
                "safety_warnings": ["Avoid application during flowering if pollinators are active.", "Apply in evening."]
            }
        ],
        "general_application_notes": "Ensure excellent coverage on leaf undersides. Apply during early morning or late evening. Rotate chemical MOA groups to prevent resistance."
    },
    "apple_codling_moth": {
        "crop": "Apple",
        "target_pest": "Codling Moth (Cydia pomonella)",
        "pest_description": "Larvae (caterpillars) bore into fruit, creating tunnels filled with frass. The 'worm in the apple'.",
        "ipm_recommendations": [
            "Use pheromone traps for monitoring and mating disruption.",
            "Apply trunk bands to trap larvae.",
            "Remove and destroy any dropped, infested fruit immediately.",
            "Time sprays based on degree-day models, not calendar."
        ],
        "chemical_options": [
            {
                "common_name": "Spinosad",
                "example_product": "Entrust SC",
                "moa_group": "5",
                "considerations": "Derived from soil bacteria. Toxic to bees until dry. PHI: 7 days. REI: 4 hours.",
                "rate_reference": "APPLY AT RATE SPECIFIED ON THE PRODUCT LABEL.",
                "safety_warnings": ["DO NOT APPLY DURING BLOOM.", "Do not apply if bees are foraging."]
            }
        ],
        "general_application_notes": "Spray timing is critical. Target egg hatch and early larval stage before they enter the fruit."
    }
}

def classify_user_intent(user_query: str) -> Optional[str]:
    """Very small keyword-based classifier to map queries to KB keys."""
    q = user_query.lower()
    if 'tomato' in q and ('aphid' in q or 'aphids' in q):
        return 'tomato_aphids'
    if 'apple' in q and ('codling' in q or 'moth' in q):
        return 'apple_codling_moth'
    return None

def generate_instructions(intent: str) -> str:
    if intent not in PESTICIDE_KNOWLEDGE_BASE:
        return "Error: Information for that crop/pest combination not found in the knowledge base."
    data = PESTICIDE_KNOWLEDGE_BASE[intent]
    lines = []
    lines.append(f"--- RECOMMENDATIONS FOR {data['crop'].upper()} - {data['target_pest'].upper()} ---")
    lines.append(f"Pest Description: {data['pest_description']}")
    lines.append("\nINTEGRATED PEST MANAGEMENT (IPM) STRATEGIES:")
    for r in data['ipm_recommendations']:
        lines.append(f" - {r}")
    lines.append("\nCHEMICAL OPTIONS (Always read the label!):")
    for chem in data['chemical_options']:
        lines.append(f"\n * {chem['common_name']} (e.g., {chem['example_product']})")
        lines.append(f"   Mode of Action Group: {chem['moa_group']}")
        lines.append(f"   Application Rate: {chem['rate_reference']}")
        lines.append(f"   Key Considerations: {chem['considerations']}")
        for w in chem['safety_warnings']:
            lines.append(f"   WARNING: {w}")
    lines.append(f"\nGeneral Application Notes: {data['general_application_notes']}")
    lines.append("\nREMEMBER: THE PRODUCT LABEL IS THE LAW. THIS IS NOT A SUBSTITUTE.")
    return '\n'.join(lines)

@app.route('/api/query', methods=['POST'])
def api_query():
    payload = request.get_json(force=True)
    query = payload.get('query', '')
    confirmed = payload.get('confirmed', False)
    if not confirmed:
        return jsonify({'error': 'You must accept the safety disclaimer before using the system.'}), 400
    intent = classify_user_intent(query)
    if not intent:
        return jsonify({'error': "Could not identify crop/pest from your query. Try 'aphids on tomato' or 'codling moth in apple'."}), 400
    instructions = generate_instructions(intent)
    return jsonify({'intent': intent, 'instructions': instructions})

@app.route('/')
def index():
    return "Crop Protection Advisory API is running. POST JSON {'query':'...','confirmed':true} to /api/query"

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
