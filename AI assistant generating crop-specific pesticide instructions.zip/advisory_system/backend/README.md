
Backend (Flask)
---------------
Run the backend:
1. python3 -m venv venv
2. source venv/bin/activate   (or venv\Scripts\activate on Windows)
3. pip install -r requirements.txt
4. python app.py
The API will run on http://localhost:5000
POST JSON to /api/query with keys: 'query' (string), 'confirmed' (bool).
