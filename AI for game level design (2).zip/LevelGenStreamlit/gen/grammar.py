import numpy as np
import random

# A tiny grammar for platformer-like segments.
# Tokens expand into column descriptors; we then rasterize into a 2D map.
#
# Legend:
# 'X' solid block, '.' air, 'C' coin, 'E' enemy, 'S' start, 'G' goal
#
# Rules generate columns with optional ground height and features.

def generate_platformer(width:int=48, height:int=16, seed:int=0):
    rng = random.Random(seed)

    # Define high-level segments
    segments = []
    while sum(len(s) for s in segments) < width:
        choice = rng.choices(
            population=['flat', 'gap', 'stair_up', 'stair_down', 'coins', 'enemies'],
            weights=[4, 1.5, 2, 2, 1.2, 1.0],
        )[0]
        if choice == 'flat':
            segw = rng.randint(4, 10)
            segments.append('F'*segw)
        elif choice == 'gap':
            segw = rng.randint(2, 4)
            segments.append('G'*segw)
        elif choice == 'stair_up':
            segw = rng.randint(4, 8)
            segments.append('U'*segw)
        elif choice == 'stair_down':
            segw = rng.randint(4, 8)
            segments.append('D'*segw)
        elif choice == 'coins':
            segw = rng.randint(4, 8)
            segments.append('C'*segw)
        elif choice == 'enemies':
            segw = rng.randint(4, 8)
            segments.append('E'*segw)

    # Flatten and trim to width
    layout_codes = ''.join(segments)[:width]

    # Rasterize columns
    base_h = height - 3  # baseline ground
    tiles = np.full((height, width), '.', dtype='<U1')
    h = base_h
    for x, code in enumerate(layout_codes):
        if code == 'F':
            pass
        elif code == 'G':
            # gap: raise ground by 1 to add variety but keep a hole
            tiles[h:, x] = '.'
            # leave it empty
        elif code == 'U':
            h = max(2, h-1)
        elif code == 'D':
            h = min(height-2, h+1)
        elif code == 'C':
            # place coins above ground
            cy = max(1, h-3)
            tiles[cy, x] = 'C'
        elif code == 'E':
            # place enemy on ground
            ey = h-1
            tiles[ey, x] = 'E'

        # draw ground for non-gap
        if code != 'G':
            tiles[h:, x] = 'X'

    # carve start/goal
    tiles[base_h-1, 1] = 'S'
    tiles[h-1, width-2] = 'G'
    return tiles
