import numpy as np
import random

def generate_cave(width:int, height:int, seed:int=0, wall_prob:float=0.45, steps:int=4,
                  birth_limit:int=4, survive_limit:int=4):
    rng = np.random.default_rng(seed)
    # 1 = wall, 0 = empty
    grid = (rng.random((height, width)) < wall_prob).astype(np.uint8)

    def neighbors(y, x):
        y0, y1 = max(0, y-1), min(height-1, y+1)
        x0, x1 = max(0, x-1), min(width-1, x+1)
        sub = grid[y0:y1+1, x0:x1+1]
        return int(np.sum(sub)) - grid[y, x]

    for _ in range(steps):
        new = grid.copy()
        for y in range(height):
            for x in range(width):
                n = neighbors(y, x)
                if grid[y, x] == 1 and n < survive_limit:
                    new[y, x] = 0
                elif grid[y, x] == 0 and n > birth_limit:
                    new[y, x] = 1
        grid = new

    # Convert to tiles: '#' = wall, '.' = floor
    tiles = np.where(grid==1, '#', '.')
    # carve start/goal on floor positions
    floors = np.argwhere(tiles=='.')
    if floors.size > 0:
        sy, sx = floors[0]
        gy, gx = floors[-1]
        tiles[sy, sx] = 'S'
        tiles[gy, gx] = 'G'
    return tiles
