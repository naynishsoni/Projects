import numpy as np
from PIL import Image, ImageDraw
import plotly.graph_objects as go

# Simple color palette for legend tiles
COLOR = {
    '#': (40, 40, 40),      # wall
    '.': (240, 240, 240),   # floor/air (light)
    'S': (0, 160, 255),     # start
    'G': (0, 200, 0),       # goal
    'X': (90, 90, 90),      # solid ground (platformer)
    'C': (240, 200, 0),     # coin
    'E': (200, 0, 0),       # enemy
}

def tiles_to_image(tiles, scale:int=16):
    h, w = tiles.shape
    img = Image.new("RGB", (w*scale, h*scale), (255,255,255))
    draw = ImageDraw.Draw(img)
    for y in range(h):
        for x in range(w):
            c = COLOR.get(tiles[y, x], (128, 128, 128))
            draw.rectangle([x*scale, y*scale, x*scale+scale-1, y*scale+scale-1], fill=c)
    return img

def tiles_to_voxels_fig(tiles):
    # Render a lightweight 3D voxel preview: place cubes for solid-like tiles.
    solid = {'#', 'X'}
    h, w = tiles.shape

    vertices_x = []
    vertices_y = []
    vertices_z = []
    i_idx = []
    j_idx = []
    k_idx = []

    cube_faces = [
        (0,1,2),(0,2,3),   # bottom
        (4,5,6),(4,6,7),   # top
        (0,1,5),(0,5,4),   # side
        (1,2,6),(1,6,5),
        (2,3,7),(2,7,6),
        (3,0,4),(3,4,7),
    ]

    cube_count = 0
    for y in range(h):
        for x in range(w):
            if tiles[y, x] in solid:
                # 8 vertices per cube
                verts = [
                    (x, 0, y), (x+1, 0, y), (x+1, 1, y), (x, 1, y),
                    (x, 0, y+1), (x+1, 0, y+1), (x+1, 1, y+1), (x, 1, y+1),
                ]
                base = len(vertices_x)
                for vx, vy, vz in verts:
                    vertices_x.append(vx)
                    vertices_y.append(vy)
                    vertices_z.append(vz)
                for a, b, c in cube_faces:
                    i_idx.append(base + a)
                    j_idx.append(base + b)
                    k_idx.append(base + c)
                cube_count += 1

    if cube_count == 0:
        fig = go.Figure()
        fig.update_layout(scene=dict(aspectmode='data'), margin=dict(l=0,r=0,t=0,b=0))
        return fig

    fig = go.Figure(data=[go.Mesh3d(
        x=vertices_x, y=vertices_y, z=vertices_z,
        i=i_idx, j=j_idx, k=k_idx,
        opacity=1.0, flatshading=True
    )])
    fig.update_layout(scene=dict(aspectmode='data'), margin=dict(l=0,r=0,t=0,b=0))
    return fig
