# A minimal educational Overlapping WFC implementation for small 2D maps.
# Learns NxN patterns from a sample image (2 or more colors) and generates a new grid.

import numpy as np
from PIL import Image

def load_sample(path:str, tile=4):
    # Downsample sample image into coarse tiles by averaging colors and thresholding.
    img = Image.open(path).convert('L')  # grayscale
    w, h = img.size
    gw, gh = w//tile, h//tile
    arr = np.array(img, dtype=np.float32)
    coarse = np.zeros((gh, gw), dtype=np.uint8)
    for y in range(gh):
        for x in range(gw):
            block = arr[y*tile:(y+1)*tile, x*tile:(x+1)*tile].mean()
            # 2 classes: floor (0) and wall (1) using a threshold
            coarse[y, x] = 1 if block < 128 else 0
    return coarse  # 0=floor, 1=wall

def extract_patterns(sample:np.ndarray, N:int=3):
    H, W = sample.shape
    pats = {}
    for y in range(H - N + 1):
        for x in range(W - N + 1):
            p = sample[y:y+N, x:x+N]
            key = tuple(p.flatten().tolist())
            pats[key] = pats.get(key, 0) + 1
    patterns = np.array([np.array(k, dtype=np.uint8).reshape(N, N) for k in pats.keys()])
    weights = np.array([pats[k] for k in pats.keys()], dtype=np.float64)
    weights /= weights.sum()
    return patterns, weights

def compatible(a:np.ndarray, b:np.ndarray, dx:int, dy:int):
    # Check if pattern b placed at offset (dx, dy) overlaps consistently with a.
    N = a.shape[0]
    x0 = max(0, dx); y0 = max(0, dy)
    x1 = min(N, N+dx); y1 = min(N, N+dy)
    if x0>=x1 or y0>=y1: return True
    A = a[y0:y1, x0:x1]
    B = b[y0-dy:y1-dy, x0-dx:x1-dx]
    return np.all(A == B)

def wfc_generate(sample:np.ndarray, out_w:int, out_h:int, N:int=3, seed:int=0, max_iters:int=20000):
    rng = np.random.default_rng(seed)
    patterns, weights = extract_patterns(sample, N=N)
    P = len(patterns)
    # domain[y][x] = possible pattern indices at top-left of pattern grid
    # We generate on a pattern grid of size (out_h, out_w); final tiles will be stitched with overlaps.
    domain = [[set(range(P)) for _ in range(out_w)] for _ in range(out_h)]
    collapsed = [[-1]*out_w for _ in range(out_h)]

    # Precompute compatibility: for each pattern p, allowed neighbors q by direction
    neighbors = {p: {'N':set(), 'S':set(), 'W':set(), 'E':set()} for p in range(P)}
    for p in range(P):
        for q in range(P):
            if compatible(patterns[p], patterns[q], 0, -1): neighbors[p]['N'].add(q)
            if compatible(patterns[p], patterns[q], 0, +1): neighbors[p]['S'].add(q)
            if compatible(patterns[p], patterns[q], -1, 0): neighbors[p]['W'].add(q)
            if compatible(patterns[p], patterns[q], +1, 0): neighbors[p]['E'].add(q)

    def entropy(cands):
        # Shannon entropy with weights
        if not cands: return 1e9
        ws = np.array([weights[i] for i in cands], dtype=np.float64)
        ws = ws / ws.sum()
        return -np.sum(ws * np.log(ws + 1e-12))

    iters = 0
    while True:
        iters += 1
        if iters > max_iters:
            break

        # Find cell with lowest entropy (>1 candidate)
        minH = 1e9; minpos = None
        for y in range(out_h):
            for x in range(out_w):
                if collapsed[y][x] != -1: continue
                H = entropy(domain[y][x])
                if len(domain[y][x]) > 1 and H < minH:
                    minH = H; minpos = (y, x)

        if minpos is None:
            # done
            break

        y, x = minpos
        # Collapse: pick a pattern by weighted random
        cands = list(domain[y][x])
        ws = np.array([weights[i] for i in cands], dtype=np.float64)
        ws /= ws.sum()
        choice = int(rng.choice(cands, p=ws))
        collapsed[y][x] = choice
        domain[y][x] = {choice}

        # Propagate constraints (simple queue)
        q = [(y, x)]
        while q:
            cy, cx = q.pop(0)
            for dy, dx, dir_from_neighbor, dir_to_neighbor in [(-1,0,'S','N'), (1,0,'N','S'), (0,-1,'E','W'), (0,1,'W','E')]:
                ny, nx = cy+dy, cx+dx
                if not (0 <= ny < out_h and 0 <= nx < out_w): continue
                allowed = set()
                for p in domain[cy][cx]:
                    allowed |= neighbors[p][dir_from_neighbor]
                before = set(domain[ny][nx])
                after = before & allowed
                if not after:
                    # Backtrack-lite: reset neighbor to all and continue (prevents dead ends for small demos)
                    after = set(range(P))
                if after != before:
                    domain[ny][nx] = after
                    q.append((ny, nx))

    # Stitch patterns into final grid by majority vote over overlaps
    Np = patterns.shape[1]
    Ht = out_h + Np - 1
    Wt = out_w + Np - 1
    votes = np.zeros((Ht, Wt), dtype=np.int32)
    counts = np.zeros((Ht, Wt), dtype=np.int32)
    for y in range(out_h):
        for x in range(out_w):
            if not domain[y][x]:
                continue
            pid = list(domain[y][x])[0] if collapsed[y][x] == -1 else collapsed[y][x]
            pat = patterns[pid]
            votes[y:y+Np, x:x+Np] += pat
            counts[y:y+Np, x:x+Np] += 1
    result = (votes / np.maximum(1, counts)) >= 0.5
    tiles = np.where(result, '#', '.')
    # Place S and G at furthest corners on floor
    tiles[1,1] = 'S'
    tiles[-2,-2] = 'G'
    return tiles
