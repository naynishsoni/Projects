import numpy as np
import networkx as nx

WALKABLE = {'.', 'S', 'G', 'C'}  # coins are walkable; enemies are obstacles for this demo

def evaluate_tiles(tiles):
    h, w = tiles.shape
    # Find S and G
    sy, sx = None, None
    gy, gx = None, None
    for y in range(h):
        for x in range(w):
            if tiles[y, x] == 'S':
                sy, sx = y, x
            elif tiles[y, x] == 'G':
                gy, gx = y, x

    # Build graph of walkable cells
    G = nx.Graph()
    for y in range(h):
        for x in range(w):
            if tiles[y, x] in WALKABLE:
                for dy, dx in [(-1,0), (1,0), (0,-1), (0,1)]:
                    ny, nx_ = y + dy, x + dx
                    if 0 <= ny < h and 0 <= nx_ < w and tiles[ny, nx_] in WALKABLE:
                        G.add_edge((y, x), (ny, nx_))

    has_path = False
    path_len = None
    if sy is not None and gy is not None and (sy, sx) in G and (gy, gx) in G:
        try:
            path = nx.shortest_path(G, (sy, sx), (gy, gx))
            has_path = True
            path_len = len(path)
        except nx.NetworkXNoPath:
            has_path = False

    # openness: ratio of walkable tiles
    open_ratio = float(np.isin(tiles, list(WALKABLE)).sum()) / float(h * w)

    # diversity: number of unique tile types used
    diversity = len(set(tiles.flatten().tolist()))

    return {
        "has_path_S_to_G": has_path,
        "shortest_path_length": path_len,
        "open_ratio": round(open_ratio, 3),
        "tile_diversity": diversity,
        "width": w,
        "height": h,
    }
