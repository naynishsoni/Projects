# Generative AI for Game Levels (3D Streamlit App)

This project demonstrates generative AI for **game level design** with:
- Procedural 2D level generation
- 3D voxel visualization
- Pathfinding & diversity metrics
- Export to OBJ for game engines

## Run Instructions
```bash
cd Generative_AI_Game_Levels_Streamlit_3D
python -m venv .venv
.venv\Scripts\activate   # Windows
pip install -r requirements.txt
streamlit run app.py
