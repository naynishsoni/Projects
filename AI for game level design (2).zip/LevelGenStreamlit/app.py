import streamlit as st
import numpy as np
from PIL import Image
from gen.cellular import generate_cave
from gen.wfc import load_sample, wfc_generate
from gen.grammar import generate_platformer
from gen.metrics import evaluate_tiles
from gen.render import tiles_to_image, tiles_to_voxels_fig
import io, json

def img_to_bytes(img: Image.Image):
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue()

st.set_page_config(page_title="Generative AI for Game Levels", layout="wide")

st.title("🧪 Generative AI for Game Levels Design")
st.caption("Cellular Automata • Wave Function Collapse • Grammar-based Platformer")

with st.sidebar:
    st.header("⚙️ Controls")
    gen_type = st.selectbox("Generator", ["Cellular Automata (Caves)", "Wave Function Collapse (WFC)", "Grammar-based Platformer"])
    seed = st.number_input("Seed", min_value=0, value=42, step=1)
    width = st.slider("Width", 16, 96, 48, step=2)
    height = st.slider("Height", 8, 64, 24, step=1)
    show_3d = st.checkbox("3D voxel preview (experimental)", value=False)

    if gen_type == "Cellular Automata (Caves)":
        wall_prob = st.slider("Initial wall probability", 0.1, 0.9, 0.45)
        steps = st.slider("Steps", 1, 8, 4)
        birth_limit = st.slider("Birth limit", 1, 8, 4)
        survive_limit = st.slider("Survive limit", 1, 8, 4)
    elif gen_type == "Wave Function Collapse (WFC)":
        N = st.slider("Pattern size (N)", 2, 5, 3)
        sample_path = "assets/wfc_sample.png"
        st.image(sample_path, caption="Current WFC Sample")
    else:
        st.info("Tip: Higher width reveals more variety across segments.")

col_btn1, col_btn2 = st.columns(2)
with col_btn1:
    generate = st.button("🎲 Generate", use_container_width=True)
with col_btn2:
    evaluate = st.button("📈 Evaluate", use_container_width=True)

# --- state ---
if "tiles" not in st.session_state:
    st.session_state.tiles = None

# --- generation ---
if generate:
    if gen_type == "Cellular Automata (Caves)":
        tiles = generate_cave(width, height, seed=seed, wall_prob=float(wall_prob), steps=int(steps),
                              birth_limit=int(birth_limit), survive_limit=int(survive_limit))
    elif gen_type == "Wave Function Collapse (WFC)":
        sample = load_sample("assets/wfc_sample.png", tile=4)
        tiles = wfc_generate(sample, out_w=max(4, width//2), out_h=max(4, height//2), N=int(N), seed=seed)
    else:
        tiles = generate_platformer(width=width, height=height, seed=seed)
    st.session_state.tiles = tiles

tiles = st.session_state.tiles

# --- display ---
if tiles is not None:
    img = tiles_to_image(tiles, scale=16)
    st.subheader("🧩 Generated Level (2D)")
    st.image(img, use_column_width=True)

    # downloads
    col_a, col_b = st.columns(2)
    with col_a:
        st.download_button("⬇️ Download PNG", data=img_to_bytes(img), file_name="level.png", mime="image/png")
    with col_b:
        payload = {"tiles": tiles.tolist()}
        st.download_button("⬇️ Download JSON", data=json.dumps(payload, indent=2).encode("utf-8"),
                           file_name="level.json", mime="application/json")

    # 3D preview
    if show_3d:
        st.subheader("🧱 3D Voxel Preview")
        fig = tiles_to_voxels_fig(tiles)
        st.plotly_chart(fig, use_container_width=True, config={"displayModeBar": False})

    # metrics
    if evaluate:
        st.subheader("📊 Evaluation Metrics")
        metrics = evaluate_tiles(tiles)
        st.json(metrics)
else:
    st.info("Choose parameters in the sidebar, then click **Generate**.")
